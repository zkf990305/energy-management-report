# juice-front-ui

```bash

# install dependency
npm install

# develop
npm run dev
```

This will automatically open http://localhost:9528
