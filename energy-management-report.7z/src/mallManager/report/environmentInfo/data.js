// const report_data = {
    //   summary: 1,
    //   classification: "electricity",
    //   type: "month",
    //   number: "2023/06",
    //   label: "用电量",
    //   content: {
    //     all_report: {
    //       title: "2023年6月用电量月报表",
    //       labelRotate: -90,
    //       total: "总用电量：66616.6 kwh",
    //       average: "日均用电量：5551.38 kwh",
    //       xvalues: [
    //         "06/13",
    //         "06/14",
    //         "06/16",
    //         "06/17",
    //         "06/18",
    //         "06/19",
    //         "06/20",
    //         "06/21",
    //         "06/22",
    //         "06/23",
    //         "06/24",
    //         "06/25",
    //       ],
    //       yvalues: [
    //         83.96, 30537.94, -9894.99, 31744.26, -1755.33, -10541.77, 11328.49,
    //         32644.3, -219510.12, 206431.85, -6389.27, 1937.28,
    //       ],
    //     },
    //     device_report: {
    //       title: "2023年6月设备用电排序图",
    //       labelRotate: -90,
    //       xvalues: [
    //         "PM_12AP13",
    //         "PM_12ALZ01",
    //         "PM_12AP14",
    //         "PM_12AP06",
    //         "PM_12AP02",
    //         "PM_12AP09",
    //         "PM_13AP06",
    //         "PM_12AP08",
    //         "PM_12AP04",
    //         "PM_13AP07",
    //         "PM_12AP12",
    //         "PM_13AP04",
    //         "PM_12AP10",
    //         "PM_12AP05",
    //         "PM_13AP03",
    //         "PM_13AP02",
    //         "PM_12AP30",
    //         "PM_13AP01",
    //         "PM_12AP01",
    //         "PM_12AP03",
    //         "PM_12AP07",
    //         "PM_12AP11",
    //         "PM_12AP15",
    //         "PM_12AP16",
    //         "PM_12AP17",
    //         "PM_12AP18",
    //         "PM_12AP19",
    //         "PM_12AP20",
    //         "PM_12AP29",
    //         "PM_13AC01",
    //         "PM_13AC02",
    //         "PM_13AP05",
    //         "PM_13AP08",
    //         "PM_13AP09",
    //         "PM_13AP10",
    //         "PM_13AP11",
    //         "PM_13AP12",
    //         "PM_12AP21",
    //       ],
    //       yvalues: [
    //         13876.31, 10642.83, 9967.9, 9297.2, 7248.71, 6034.4, 4112.08,
    //         3208.16, 1247.37, 1149.68, 1137.14, 701.92, 689.34, 652.31, 593.42,
    //         365.52, 270.61, 9.36, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    //         0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -4587.66,
    //       ],
    //     },
    //     ingredients_report: {
    //       title: "2023年6月用电成分图",
    //       xvalues: ["照明用电--16%--16%", "生产用电--84%--84%"],
    //       yvalues: [
    //         {
    //           value: 10642.83,
    //           name: "照明用电--16%",
    //         },
    //         {
    //           value: 55973.77,
    //           name: "生产用电--84%",
    //         },
    //       ],
    //     },
    //   },
    //   username: "tangyuan",
    //   ReportTime: "2023年6月28日 11:55:19",
    // };

const report_data = {
      summary: 1,
      classification: "electricity",
      type: "month",
      number: "",
      label: "",
      content: {
        all_report: {
          title: "",
          labelRotate: -90,
          total: "",
          average: "",
          xvalues: [
            
          ],
          yvalues: [
           
          ],
        },
        device_report: {
          title: "",
          labelRotate: -90,
          xvalues: [
          
          ],
          yvalues: [
           
          ],
        },
        ingredients_report: {
          title: "",
          xvalues: [],
          yvalues: [
            {
              value: ,
              name: "",
            },
            {
              value: ,
              name: "",
            },
          ],
        },
      },
      username: "",
      ReportTime: "",
    };