<template>
  <!-- <dashboard-info /> -->
  <info />
</template>

<script>
import DashboardInfo from "@/mallManager/report/device/dashboardInfo/dashboardInfo.vue";
import Info from "@/mallManager/report/device/dashboardInfo/index.vue";
export default {
  components: {
    DashboardInfo,
    Info,
  },
};
</script>

<style>
</style>