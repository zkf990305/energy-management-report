import Cookies from 'js-cookie'

const NameKey = 'vue_admin_template_token'

export function getName() {
  return Cookies.get(NameKey)
}

export function setName(name) {
  return Cookies.set(NameKey, name)
}

export function removeName() {
  return Cookies.remove(NameKey)
}
