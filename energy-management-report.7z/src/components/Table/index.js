export { default as BasicTable } from './src/BasicTable.vue'

