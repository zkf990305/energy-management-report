export { default as Kanban } from './src/Kanban.vue'
