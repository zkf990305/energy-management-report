export { default as Pagination } from './src/Pagination.vue'

