export { default as UploadImage } from './src/UploadImage.vue'
